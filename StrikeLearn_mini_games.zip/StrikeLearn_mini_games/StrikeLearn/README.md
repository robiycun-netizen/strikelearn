# StrikeLearn Prototype

Updated with the requested authentication and dashboard learning flow.

- Signup has a blue Create account button and a small grey "Already have an account? Log in" link.
- Login has a Log in button and a small grey "Don't have an account? Create an account" link.
- New users see "Ready to learn?" and "Start a lesson! →" on the dashboard.
- Users who have started a lesson and have not completed it see "Continue Learning" and "Continue →" to return to that lesson.
- Last lesson is remembered in localStorage.
- StrikeLearn branding is applied.

Prototype only: authentication/data use localStorage and should be replaced by a secure backend/database for production.

- Login and signup include a simple arithmetic CAPTCHA demo. This is NOT Google reCAPTCHA or bot protection; production requires server-side verification and a real CAPTCHA provider.
